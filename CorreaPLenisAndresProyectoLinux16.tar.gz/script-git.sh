#!/bin/bash

#Paula Correa  Andres Lenis

opciones=("Git" "Administrar repositorios")
opcionesIns=("instalar" "desinstalar" "actualizar")
opcionesGit=("crear repositorio remoto y local" "crear Repositorio Local" "crear Repositorio Remoto" "clonar" "administrar ramas" "administración de archivos" "eliminar")
opcionesRamas=("crear rama local" "crear rama remota" "cambiar rama" "eliminar rama local" "eliminar rama remota")
opcionesArchivos=("crear" "modificar" "visualizar" "eliminar"  "actualizarLocal" "actualizarRemoto" "mezclar")

while PS4=$(zenity --title "Opciones" --text="Escoja una opcion:" --list \
	--column="Opciones" "${opciones[@]}"); do

	case "$PS4" in
		"${opciones[0]}" )
			repeticiones=$(cat /etc/*release | grep -c 'redhat')
			if [ "$repeticiones" = "0" ]
				then

				while PS3=$(zenity --title "Opciones Git" --text="Escoja una opcion:" --list \
				--column="OpcionesIns" "${opcionesIns[@]}"); do

					case "$PS3" in
						"${opcionesIns[0]}" ) 
						dpkg -s git
						instalado=$?
						echo $instalado
						if [ "$instalado" = "1" ]
						then
							sudo apt-get -y install git
							email=$(zenity --entry --text="Ingrese correo asociado a git")
							usuario=$(zenity --entry --text="Ingrese usuario asociado a git")

							git config --global user.email $email
							git config --global user.name $usuario
							zenity --info --title="Éxito" --text="Git se ha instalado correctamente"
						else
							zenity --info --title="Error" --text="Git ya está instalado"
						fi;;
						"${opcionesIns[1]}" )
						dpkg -s git
						instalado=$?
						echo $instalado
						if [ "$instalado" = "0" ]
						then
							sudo apt-get -y remove git
							sudo apt-get -y purge git
						else
							zenity --info --title="Error" --text="Git no esta instalado"
						fi;;
						"${opcionesIns[2]}" )
						dpkg -s git
						instalado=$?
						echo $instalado
						if [ "$instalado" = "0" ]
						then
							sudo apt-get -y upgrade git
						else
							zenity --info --title="Error" --text="Git no esta instalado"
						fi;;
					esac
				done 

			else
				while PS3=$(zenity --title "Opciones Git" --text="Escoja una opcion:" --list \
				--column="OpcionesIns" "${opcionesIns[@]}"); do

					case "$PS3" in
						"${opcionesIns[0]}" ) 
						yum list installed git
						instalado=$?
						echo $instalado
						if [ "$instalado" = "1" ]
						then
							sudo yum -y install git
							email=$(zenity --entry --text="Ingrese correo asociado a git")
							usuario=$(zenity --entry --text="Ingrese usuario asociado a git")
							git config --global user.email $email
							git config --global user.name $usuario
							zenity --info --title="Éxito" --text="Git se ha instalado correctamente"
						else
							zenity --info --title="Error" --text="Git ya está instalado"
						fi;;
						"${opcionesIns[1]}" )
						yum list installed git
						instalado=$?
						echo $instalado
						if [ "$instalado" = "0" ]
						then
							sudo yum -y remove git
						else
							zenity --info --title="Error" --text="Git no esta instalado"
						fi;;
						"${opcionesIns[2]}" )
						yum list installed git
						instalado=$?
						echo $instalado
						if [ "$instalado" = "0" ]
						then
							sudo yum -y update git
						else
							zenity --info --title="Error" --text="Git no esta instalado"
						fi;;
					esac
				done
			fi				
		;;

		"${opciones[1]}" )
			while PS2=$(zenity --title "Opciones Repositorios" --text="Escoja una opcion:" --list \
					--column="OpcionesGit" "${opcionesGit[@]}"); do

					case "$PS2" in
						"${opcionesGit[0]}" )
						dir1=$(zenity --file-selection --directory)
						cd $dir1
						dir2=$(zenity --entry --text="Ingrese nombre del directorio")
						mkdir $dir2
						cd $dir2
						git --bare init
						dir3=$(zenity --file-selection --directory)
						cd $dir3
						dir4=$(zenity --entry --text="Ingrese nombre del directorio")
						mkdir $dir4
						cd $dir4
						touch .gitignore
						git init
						git add .
						git commit -m "commit inicial"
						git remote add origin $dir1/$dir2
						git push origin master;;

						"${opcionesGit[1]}" )
						dir1=$(zenity --file-selection --directory)
						cd $dir1
						dir2=$(zenity --entry --text="Ingrese nombre del directorio")
						mkdir $dir2
						cd $dir2
						touch .gitignore
						git init
						git add .
						git commit -m "commit inicial";;
						
						"${opcionesGit[2]}" )
						dir1=$(zenity --file-selection --directory)
						cd $dir1
						dir2=$(zenity --entry --text="Ingrese nombre del directorio")
						mkdir $dir2
						cd $dir2
						git --bare init;;

						"${opcionesGit[3]}" )
						dir1=$(zenity --file-selection --directory)
						cd $dir1
						dir2=$(zenity --file-selection --directory)
						git clone $dir2;;


						"${opcionesGit[4]}" )
							while PS5=$(zenity --title "Opciones" --text="Escoja una opcion:" --list \
								--column="opcionesRamas" "${opcionesRamas[@]}"); do
								case "$PS5" in
									"${opcionesRamas[0]}" )
									dir1=$(zenity --file-selection --directory)
									cd $dir1
									dir2=$(zenity --entry --text="Ingrese nombre de la nueva rama")
									git branch $dir2;;

									"${opcionesRamas[1]}" )
									dir1=$(zenity --file-selection --directory)
									cd $dir1
									dir2=$(zenity --entry --text="Ingrese nombre de la nueva rama")
									git branch $dir2
									git commit -m "rama "$dir2" creada"
									dir3=$(zenity --file-selection --directory)
									git push $dir3 $dir2;;

									"${opcionesRamas[2]}" )
									dir1=$(zenity --file-selection --directory)
									cd $dir1
									dir2=$(zenity --entry --text="Ingrese nombre de la rama")
									git checkout $dir2;;

									"${opcionesRamas[3]}" )
									dir1=$(zenity --file-selection --directory)
									cd dir1
									dir2=$(zenity --entry --text="Ingrese nombre de la rama")
									git branch -d $dir2;;

									"${opcionesRamas[4]}" )
									dir1=$(zenity --file-selection --directory)
									cd $dir1
									dir2=$(zenity --entry --text="Ingrese nombre de la rama")
									git branch -d $dir2
									git commit -m "eliminada rama ".$dir2
									git push origin:$dir2
									;;
								esac
							done;;
						"${opcionesGit[5]}" )
							while PS6=$(zenity --title "Opciones" --text="Escoja una opcion:" --list \
							--column="opcionesArchivos" "${opcionesArchivos[@]}"); do
								case "$PS6" in
									"${opcionesArchivos[0]}" )
									dir1=$(zenity --file-selection --directory) #local
									cd $dir1
									nombre=$(zenity --entry --text="Ingrese nombre del archivo que se desea crear")
									touch $nombre
									git add $nombre
									git commit -m "agregado archivo "$nombre;;


									"${opcionesArchivos[1]}" );;

									"${opcionesArchivos[2]}" )
									dir1=$(zenity --file-selection --directory)
									cd $dir1
									listar=$(ls)
									zenity --info --title="Lista de archivos" --text="$listar"
									;;

									"${opcionesArchivos[3]}" )
									dir1=$(zenity --file-selection --directory) #local
									cd $dir1
									elim=$(zenity --entry --text="¿Qué archivo desea eliminar")
									rm $elim
									git rm $elim
									git commit -m "eliminafdo archivo "$elim
									;;

									"${opcionesArchivos[4]}" )
										dir1=$(zenity --file-selection --directory) #remoto
										echo $dir1
										dir2=$(zenity --file-selection --directory) #local
										cd $dir2
										dir3=$(zenity --entry --text="Ingrese nombre de la rama")
										git pull $dir1 $dir3;;

									"${opcionesArchivos[5]}" )
										dir1=$(zenity --file-selection --directory) #local
										cd $dir1
										dir2=$(zenity --file-selection --directory) #remoto
										git push $dir2
									;;

									"${opcionesArchivos[6]}" )
									dir1=$(zenity --file-selection --directory)
									cd $dir1
									rama1=$(zenity --entry --text="Introduzca nombre de rama 1")
									rama2=$(zenity --entry --text="Introduzca nombre de rama 2")
									git checkout $rama1
									git merge $rama2
									;;
								esac
							done;;
                                                "${opcionesGit[6]}" )
						dir1=$(zenity --file-selection --directory)
						rm -rf $dir1;;
					esac
			done;;
	esac
done
