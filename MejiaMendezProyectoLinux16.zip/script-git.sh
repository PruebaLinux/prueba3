#!/bin/bash
###############################
#
#
#       PROYECTO FINAL LINUX PARA INGENIERIA
#       INTEGRANTES:
#           JUAN PABLO MEJIA
#           JUAN PABLO MENDEZ
#
#
###############################



installGitRedHat()
{
  opt=$(zenity --print-column 2 --hide-column 2 --list --title="Opciones de instalacion GIT" --text "Seleccione la operación a realizar" --column "Operación" --column "Comando" "Actualizar GIT" "*" "Desinstalar GIT" "-")
  #Si selecciona actualizar
  if [ "$opt" == "*" ]; then
      sudo yum makecache
      sudo yum -y update git
      zenity --info --text="Su sistema ha actualizado el paquete GIT"
  
  #Si selecciona desinstalar
  elif [ "$opt" == "-" ]; then
      sudo yum -y remove git
      zenity --info --text="Se ha desinstalado GIT"
      main
  fi 
}

installGitDebian()
{
  opt=$(zenity --print-column 2 --hide-column 2 --list --title="Opciones de instalacion GIT" --text "Seleccione la operación a realizar" --column "Operación" --column "Comando" "Actualizar GIT" "*" "Desinstalar GIT" "-")
  #Si selecciona actualizar
  if [ "$opt" == "*" ]; then
      sudo apt-get update
      sudo apt-get -y upgrade git
      zenity --info --text="Su sistema ha actualizado el paquete GIT"
  
  #Si selecciona desinstalar
  elif [ "$opt" == "-" ]; then
      sudo apt-get -y autoremove git
      sudo apt-get -y purge git
      zenity --info --text="Se ha desinstalado GIT"
  fi 
}

adminRepos()
{
    opt=$(zenity --print-column 2 --hide-column 2 --list --title="Administrador Repositorios" --text "Seleccione la operación a realizar" --column "Operación" --column "Comando" "Configurar cuenta" "+" "Clonar repositorio" "-" "Crear repositorio" "*" "Eliminar repositorio" "/" "Agregar archivo" "=" "Eliminar archivo" "!=" "Crear rama" "&")
    if [ "$opt" == "+" ]; then
      confGit
      adminRepos
    elif [ "$opt" == "-" ]; then
      clonRep
      adminRepos
    elif [ "$opt" == "*" ]; then
      crearRep
      adminRepos
    elif [ "$opt" == "/" ]; then
      delRep
      adminRepos
    elif [ "$opt" == "=" ]; then
      addFile
      adminRepos
    elif [ "$opt" == "!=" ]; then
      delFile
      adminRepos
    elif [ "$opt" == "&" ]; then
      createBranch
      adminRepos
    fi
    
}

confGit()
{
  data=$(zenity --forms --add-entry="User name" --add-entry="Email" --title="Configurar cuenta" --separator=" " --text="Configurar cuenta")
  data=($data)
  name="${data[0]}"
  email="${data[1]}"
  git config --global user.name "$name"
  git config --global user.email "$email"
  zenity --info --text="Se ha configurado correctamente la cuenta\nUsuario: $name\nCorreo: $email"
}
createRep()
{
  name=$(zenity --entry --text="Ingresa el nombre del repositorio" --title="Crear un repositorio")
  zenity --info --text="Seleccione el directorio donde se creara el repositorio $name"
  directory=$(zenity --file-selection --directory)
  cd "$directory"
  mkdir "$name"
  cd "$name"
  git init
  git commit -m "Initial project version of $name"
}
delRep()
{
  zenity --info --text="Seleccione el directorio donde se encuentra el repositorio a borrar"
  directory=$(zenity --file-selection --directory)
  rm -rf "$directory"
}
clonRep()
{
  path=$(zenity --entry --text="Ingresa la ruta del repositorio a clonar" --title="Crear un repositorio")
  zenity --info --text="Seleccione el directorio donde se clonara el repositorio"
  directory=$(zenity --file-selection --directory)
  cd "$directory"
  git clone "$path"
}
addFile()
{
  zenity --info --text="Seleccione el archivo a seguir"
  name=$(zenity --file-selection)
  zenity --info --text="Seleccione el repositorio que hara seguimiento del archivo"
  directory=$(zenity --file-selection --directory)
  cd "$directory"
  git add "$name"
}
delFile()
{
  zenity --info --text="Seleccione el archivo a borrar"
  name=$(zenity --file-selection)
  rm "$name"
}
createBranch()
{
  name=$(zenity --entry --text="Ingresa el nombre de la rama a crear" --title="Crear una rama")
  zenity --info --text="Seleccione el repositorio al que se le agregara una rama"
  directory=$(zenity --file-selection --directory)
  cd "$directory"
  git branch "$name"
}
main()
{
  distro=$(cat /etc/*release | grep -c "debian")
  if [ "$distro" == "0" ]; then
      echo "Es un sistema RedHat"
      yum list installed git
      inst=$?
      #Pregunta si está instalado git
      if [ "$inst" == "1" ]; then #Si no esta esta instalado
        zenity --question --text="El paquete GIT no se encuentra instalado.\n\n¿Desea instalar el paquete GIT \nen este dispositivo?" --title="Instalar"
        yes=$?
        if [ "$yes" == "0" ]; then
            sudo yum -y makecache
            sudo yum -y install git
            zenity --info --text="Su sistema ahora tiene instalado GIT"
        fi
      else #Si esta instalado
        opt=$(zenity --print-column 2 --hide-column 2 --list --title="Administrador GIT" --text "Seleccione la operación a realizar" --column "Operación" --column "Comando" "Opciones de instalacion GIT" "*" "Gestionar repositorios" "-")
        if [ "$opt" == "*" ]; then
          installGitRedHat
          main
        elif [ "$opt" == "-" ]; then
          adminRepos
        fi
      fi  
  else
      echo "Es un sistema Debian"
      dpkg -s git
      inst=$?
      #Pregunta si está instalado git
      if [ "$inst" == "1" ]; then #Si no esta esta instalado
        zenity --question --text="El paquete GIT no se encuentra instalado.\n\n¿Desea instalar el paquete GIT \nen este dispositivo?" --title="Instalar"
        yes=$?
        if [ "$yes" == "0" ]; then
            sudo apt-get update
            sudo apt-get -y --force-yes install git
            zenity --info --text="Su sistema ahora tiene instalado GIT"
        fi
      else #Si esta instalado
        opt=$(zenity --print-column 2 --hide-column 2 --list --title="Administrador GIT" --text "Seleccione la operación a realizar" --column "Operación" --column "Comando" "Opciones de instalacion GIT" "*" "Gestionar repositorios" "-")
        if [ "$opt" == "*" ]; then
          installGitDebian
          main
        elif [ "$opt" == "-" ]; then
             adminRepos  
        fi
      fi
  fi
}

main