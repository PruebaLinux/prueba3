#!/bin/bash

grep 'debian' /etc/*-release
debian=$(echo $?)
 

grep 'redhat' /etc/*-release
redhat=$(echo $?)

if [ $debian -eq 0 ]
then
	sudo apt-get update 
	sudo apt-get install git
	zenity --info --text="Se ha actualizado git apropiadamente"

elif [ $redhat -eq 0]
then
	sudo yum update git
	zenity --info --text="Se ha actualizado git apropiadamente"

else

	zenity --info --text="Su sistema no es soportado por este programa"

fi