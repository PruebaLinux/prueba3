#!/bin/bash

direccion=$(zenity --file-selection --directory --title="Seleccione la carpeta con el repositorio que quiere actualizar respecto al remoto")
cd $direccion

if [ $? -eq 0 ]; 
then
	form=$(zenity --forms --title="Clonar repositorio git" --text="Datos repositorio" --add-entry="Nombre de la rama local a actualizar" --add-entry="Nombre de la rama remota sobre la que desea hacer la actualizacion" --separator=" ")
	echo $form
	git pull $form
	if [ $? -eq 0 ];
	then	
		zenity --info \
		--text="Se efectuo actualizacion correctamente."
	else
		zenity --error \
		--text="No se pudo realizar la accion. Verifique los parametros ingresados."
	fi
else
	zenity --error \
	--text="No se encontro la carpeta seleccionada."
fi
