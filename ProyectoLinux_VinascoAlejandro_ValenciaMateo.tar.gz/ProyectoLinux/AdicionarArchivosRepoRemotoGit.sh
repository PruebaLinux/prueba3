#!/bin/bash


direccion=$(zenity --file-selection --directory --title="Seleccione la ruta donde esta sincronizado el repositorio remoto" --separator=" ")
nombre=""
rama=""

cd $direccion

if [ $? -eq 0 ]; then
	datosRepoRemoto=$(zenity --forms --title="Datos Repositorio Remoto" --text=" " --add-entry="Nombre" --add-entry="Rama" --separator=" ")
	git push -u $datosRepoRemoto
	for var in $datosRepoRemoto; do
    	if [ $i = 0 ]
    	then 
        	nombre=$var

    	elif [ $i = 1 ]
    	then
    		rama=$var

    	fi
    	let i++
	done
	if [ $? -eq 0 ]; then
		zenity --info \
		--text="Se subieron los archivos correctamente a la rama $rama del repositorio remoto $nombre de la rama $rama"
	else
		zenity --error \
		--text="Ocurrio un error subiendo los archivos. Revise el nombre y la rama del repositorio."
	fi

else
	zenity --error \
	--text="Ocurrio un error subiendo los archivos."
fi 