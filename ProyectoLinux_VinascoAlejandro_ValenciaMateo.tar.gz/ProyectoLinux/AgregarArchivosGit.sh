#!/bin/bash
archivos=$(zenity --file-selection --multiple --title="Seleccione los archivos a agregar para su repositorio local" --separator=" ")
direccion$(zenity --file-selection --directory --title="Seleccione el direcctorio del repositorio al que desea agregar los archivos" --separator=" ")


cd $direccion
if [ $? -eq 0 ]; then	
	for var in $direccion; do
		git add $var
	done
	comentario=$(zenity --forms --title="Commit" --text="Comentario" --add-entry="")
	if [ $? -eq 0 ]; then
		git commit -m "$comentario"
	else
		zenity --error \
		--text="No se pudieron adicionar los archivos seleccionados ya que no se agrego ningun comentario."
	fi
	
else
	zenity --error \
	--text="No se pudieron adicionar los archivos seleccionados."
fi

