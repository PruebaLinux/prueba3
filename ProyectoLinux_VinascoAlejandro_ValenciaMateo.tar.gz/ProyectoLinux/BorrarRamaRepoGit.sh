#!/bin/bash

direccion=$(zenity --file-selection --directory --title="Seleccione la ruta donde esta sincronizado el repositorio con la rama que desea elminar" --separator=" ")

cd $direccion

if [ $? -eq 0 ]; then
	branch=$(zenity --entry --text="Escriba el nombre de la rama que desea eliminar")
	
	estado=$(zenity --list --radiolist --column=Selec\. --column=Opcion --text="Desea eliminar la rama del repositorio local, del repositorio remoto, o de ambos?" FALSE "Local" FALSE "Remoto" FALSE "Ambos")
		
	if [ $estado = "Remoto" ];then

		name=$(zenity --entry --title="Nombre Repositorio" --text="Escriba el nombre de su repositorio remoto (como lo coloco para configurar el nombre del remoto)")
		git push $name :$branch

		if [$? -eq 0 ]; then 
			zenity --info\
			--text="Se ha eliminado la rama remota satisfactoriamente"	

		else
			zenity --info\
			--text="Ha ocurrido un problema eliminando la rama en el repositorio remoto. Revise si existe dicha rama en el remoto e intente de nuevo."	

		fi

	elif [ $estado = "Local" ];then
		git branch -d $branch
		if [$? -eq 0 ]; then 
			zenity ---info --text="Se ha eliminado la rama $branch satisfactoriamente"		

		else
			zenity --info\
			--text="Ha ocurrido un problema eliminando la rama en el repositorio local. Por favor verifique que esta existe en el repositorio local e intente de nuevo"	

		fi

	elif [ $estado = "Ambos" ]; then
		git branch -d $branch

		if [$? -eq 0 ]; then 
			name=$(zenity --entry --title="Nombre Repositorio" --text="Escriba el nombre de su repositorio(como lo coloco para configurar el nombre del remoto)")
			git push $name :$branch

			if [$? -eq 0 ]; then 
				zenity --info\
				--text="Se ha eliminado la rama satisfactoriamente de todos los repositorios"	

			else
				zenity --info\
				--text="Ha ocurrido un problema eliminando la rama en el repositorio remoto. Revise si existe dicha rama en el remoto e intente de nuevo."	

			fi

		else
			zenity --info\
			--text="Ha ocurrido un problema eliminando la rama en el repositorio local. Por favor verifique que esta existe en el repositorio local e intente de nuevo"	

		fi
		

	else
		zenity --error\
		--text="Por una situacion interna del programa, se ha decidido no eliminar la rama de ninguno de los repositorios"	

	fi
		
else
	zenity --error \
	--text="Ocurrio un error accediendo al directorio del repositorio."
fi