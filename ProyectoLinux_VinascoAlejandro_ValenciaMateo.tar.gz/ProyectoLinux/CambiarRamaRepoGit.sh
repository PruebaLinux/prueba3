#!/bin/bash

direccion=$(zenity --file-selection --directory --title="Seleccione la ruta donde esta sincronizado el repositorio cuya rama principal desea modificar" --separator=" ")

cd $direccion

if [ $? -eq 0 ]; then
	branch=$(zenity --entry --text="Escriba el nombre de la rama que desea que pase a ser la rama actual del repositorio")
	git checkout $branch
	if [ $? -eq 0 ]; then
		
		zenity ---info --text="La rama $branch a pasado a ser la rama actual del repositorio"

	else
		zenity --error\
		--text="No se pudo cambiar la rama actual del repositorio."	

	fi
		
else
	zenity --error \
	--text="Ocurrio un error accediendo al directorio del repositorio."
fi