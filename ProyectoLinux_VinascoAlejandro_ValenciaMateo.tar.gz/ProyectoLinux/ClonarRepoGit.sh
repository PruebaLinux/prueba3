#!/bin/bash

direccion=$(zenity --file-selection --directory --title="Seleccione la carpeta donde desea clonar su repositorio")
cd $direccion

if [ $? -eq 0 ]; then
	
	git init

	if [ $? -eq 0 ]; then

		estado=$(zenity --list --radiolist --column=Selec\. --column=Opcion --text="Desea copiar un repositorio local o uno remoto?" FALSE "Local" FALSE "Remoto")
		
		if [ $estado = "Local" ];then

			form=$(zenity --file-selection --directory --title="Seleccione la carpeta del repositorio que desea clonar")
			name=$(zenity --entry --title="Nombre Repositorio" --text="Escriba el nombre de su repositorio(como lo coloco para configurar el nombre del remoto)")
			git clone $form $name
			
			if [$? -eq 0 ]; then 
				zenity --info\
				--text="Se ha clonado el repositorio local correctamente"	

			else
				zenity --info\
				--text="Ha ocurrido un problema clonando el repositorio. Revise si el directorio a clonar ha sido inicializado como repositorio local."	
			fi

		elif [ $estado = "Remota" ];then
			
			form=$(zenity --forms --title="Clonar repositorio git" --text="Datos repositorio" --add-entry="URL" --add-entry="Nombre de la rama principal" --separator=" ")
			git clone $form

			if [ $? -eq 0 ];then	
				zenity --info \
				--text="Se efectuo la clonacion del repositorio remoto correctamente."

			else
				zenity --error \
				--text="No se pudo realizar la accion. Verifique los parametros ingresados."

			fi

		else 
			zenity --info\
			--text="No ha proporcionado una opcion de repositorio a clonar. Se ha dejado un repositorio inicializado en el directorio dado"

		fi

	
else
	zenity --error \
	--text="No se encontro la carpeta seleccionada."
fi

