#!/bin/bash

direccion=$(zenity --file-selection --directory --title="Seleccione la ruta donde esta sincronizado el repositorio con la rama que desea combinar" --separator=" ")

cd $direccion

if [ $? -eq 0 ]; then
	branch=$(zenity --entry --text="Escriba el nombre de la rama que desea combinar")
	git merge $branch
	if [ $? -eq 0 ]; then

		estado=$(zenity --list --radiolist --column=Selec\. --column=Opcion --text="Desea que la combinacion permanezca local o que se agrege al repositorio remoto?" FALSE "Local" FALSE "Remoto")
		
		if [ $estado = "Remota" ];then

			name=$(zenity --entry --title="Nombre Repositorio" --text="Escriba el nombre de su repositorio(como lo coloco para configurar el nombre del remoto)")
			git push $name $branch

			if [$? -eq 0 ]; then 
				zenity --info\
				--text="Se ha creado la rama remota satisfactoriamente"	

			else
				zenity --info\
				--text="Ha ocurrido un problema subiendo la rama al repositorio. Esta quedara local por el momento."	

			fi

		elif [ $estado = "Local" ];then
			zenity ---info --text="Se han combinado la rama $branch y la rama activa satisfactoriamente"	

		else 
			zenity --info\
			--text="Dado a condiciones internas del programa, se ha dejado la combinacion de forma local"

		fi

	else
		zenity --error\
		--text="No se pudo combinar la rama $branch con la rama activa del repositorio. Revise y resuelva los conflictos de los archivos
		que haya modificado recientemente"	

	fi
		
else
	zenity --error \
	--text="Ocurrio un error accediendo al directorio del repositorio."
fi