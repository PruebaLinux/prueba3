#!/bin/bash

i=0
direccion=$(zenity --file-selection --directory --title="Seleccione la carpeta para su repositorio local")
name=""
email=""

cd $direccion
if [ $? -eq 0 ]; then
	
	git init

	if [ $? -eq 0 ]; then
		zenity --info --text="Por favor, ingrese su nombre y su correo de preferencia (o, en caso que tenga una cuenta en un repositorio remoto, su usuario y el correo con el que esa registrado"
		datos=$(zenity --forms --title="Datos del usuario" --text="Datos del usuario" --add-entry="Nombre de usuario" --add-entry="Email" --separator=" ")
		
		for var in $datos; do
		
    		if [ $i = 0 ]
    		then 
        		name=$var

    		elif [ $i = 1 ]
    		then
    			email=$var

    		fi
    		let i++

		done
		echo "Nombre: $name"
		echo "Email: $email"
		git config --global user.name "$name"
		git config --global user.email "$email"
		zenity --info --text="Se creo el repositorio local en esta direccion: $direccion"	
	else
		zenity --error \
		--text="No se creo logro crear el repositorio local."

	fi
	
else
	zenity --error --text="No se creo logro acceder al directorio especificado."
fi
