#!/bin/bash

direccion=$(zenity --file-selection --directory --title="Seleccione la carpeta que desea sincronizar con su repositorio remoto")

cd $direccion	

if [ $? -eq 0 ]; then
	git init
	form=$(zenity --forms --title="Conectar repositorio remoto git" --text="Datos repositorio" --add-entry="Nombre del repositorio" --add-entry="URL"  --separator=" ")
	git remote add $form

	if [ $? -eq 0 ]; then
		zenity --info --text="Por favor, ingrese su nombre y su correo de preferencia (o, en caso que tenga una cuenta en un repositorio remoto, su usuario y el correo con el que esa registrado"
		datos=$(zenity --forms --title="Datos del usuario" --text="Datos del usuario" --add-entry="Nombre de usuario" --add-entry="Email" --separator=" ")
		if [ $? -eq 0 ];then 
			for var in $datos; do
			
    			if [ $i = 0 ]
    			then 
        			name=$var

    			elif [ $i = 1 ]
    			then
    				email=$var

    			fi
    			let i++

			done
			echo "Nombre: $name"
			echo "Email: $email"
			git config --global user.name "$name"
			git config --global user.email "$email"

			zenity --info \
			--text="Se creo correctamente el repositorio y se conecto al remoto determinado."
		else

			zenity --info \
			--text="Se creo correctamente el repositorio, pero por problemas con el ingreso de la informacion personal no se conecto al remoto determinado apropiadamente. Ingrese manualmente el nombre de usuario y correo con que tiene cuenta en el repositorio remoto"
		fi

	else
		zenity --error \
		--text="No se pudo crear el repositorio remoto."

	fi

else
	zenity --error \
	--text="No se pudo acceder a la direccion especificado."	

fi


