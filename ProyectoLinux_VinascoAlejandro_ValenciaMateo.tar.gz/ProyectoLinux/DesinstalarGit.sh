#!/bin/bash
grep 'debian' /etc/*-release
debian=$(echo $?)
 

grep 'redhat' /etc/*-release
redhat=$(echo $?)

if [ $debian -eq 0 ]
then
	sudo apt-get remove git
	zenity --info --text="Se ha desinstalado git apropiadamente"

elif [ $redhat -eq 0]
then
	
	sudo yum remove git
	zenity --info --text="Se ha desinstalado git apropiadamente"

else

	zenity --info --text="Su sistema no es soportado por este programa"

fi