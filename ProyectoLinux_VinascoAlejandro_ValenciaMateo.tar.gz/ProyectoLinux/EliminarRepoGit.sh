#!/bin/bash

direccion=$(zenity --file-selection --directory --title="Seleccione la carpeta del repositorio que desea eliminar")

if [ $? -eq 0 ]; 
then
	cd $direccion
	rm -rf .git
	if [ $? -eq 0 ];
	then
		zenity --info --text="Se elimino el repositorio local en esta direccion: $direccion"
	else
		zenity --error --text="No se encontro ningun repositorio local."
	fi
else
	zenity --error --text="No se encontro ningun repositorio local."
fi
