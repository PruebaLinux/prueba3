#!/bin/bash

direccion=$(zenity --file-selection --directory --title="Seleccione la ruta donde esta el repositorio que desea ramificar" --separator=" ")

cd $direccion

if [ $? -eq 0 ]; then
	branch=$(zenity --entry --title="Nombre rama" --text="Escriba el nombre que desea tenga su rama")
	git branch $branch
	if [ $? -eq 0 ]; then
		estado=$(zenity --list --radiolist --column=Selec\. --column=Opcion --text="Desea que su rama permanezca local o sea remota?" FALSE "Local" FALSE "Remota")
		
		if [ $estado = "Remota" ];then
			git commit -m "Creacion Rama $branch"
			name=$(zenity --entry --title="Nombre Repositorio" --text="Escriba el nombre de su repositorio(como lo coloco para configurar el nombre del remoto)")
			git push $name $branch
			if [$? -eq 0 ]; then 
				zenity --info\
				--text="Se ha creado la rama remota satisfactoriamente"	

			else
				zenity --info\
				--text="Ha ocurrido un problema subiendo la rama al repositorio. Esta quedara local por el momento."	
			fi
		elif [ $estado = "Local" ];then
			zenity --info\
			--text="Se ha creado la rama satisfactoriamente, de manera local"	

		else 
			zenity --info\
			--text="Dado a condiciones internas del programa, se ha dejado la rama en estado local"

		fi

	else
		zenity --error\
		--text="Ocurrio un error en la creacion de la rama. Es posible que no tenga un repositorio activo en el directorio dado, o que su repositorio no puede hacer seguimiento a las ramas porque no posee un repositorio remoto para hacerle seguimiento"	

	fi
		
else
	zenity --error \
	--text="Ocurrio un error accediendo al directorio del repositorio."

fi
