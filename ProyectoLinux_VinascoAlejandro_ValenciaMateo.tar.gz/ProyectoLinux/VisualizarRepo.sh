#!/bin/bash

direccion=$(zenity --file-selection --directory --title="Seleccione la ruta para visualizar el estado de su repositorio local.")

if [ $? -eq 0 ]; then
	cd $direccion
	estado=$(git status)
	if [ $? -eq 0 ]; then
		zenity --info --text="La informacion del repositorio es la siguiente: $estado"
	else
		zenity --error --text="No se puede mostrar la información. Puede que la dirección sea errónea."
	fi
else
	zenity --error --text="No se seleccionó correctamente la dirección."
fi
