#!/bin/bash

comando=$(zenity --hide-column 3 --print-column 3 --list --radiolist --width=500 --height=500  \
--column "Selec" \
--column "Accion" \
--column "Comando (oculto)" \
--text "Seleccione la accion a realizar" \
FALSE "Instalar Git" "./InstalarGit.sh"  \
FALSE "Desinstalar Git" "./DesinstalarGit.sh" \
FALSE "Actualizar Git" "./ActualizarGit.sh" \
FALSE "Crear un repositorio local" "./CrearRepoGit.sh" \
FALSE "Crear un repositorio local y conectarlo a un repositorio remoto" "./CrearRepoRemotoGit.sh" \
FALSE "Clonar un repositorio de git (local o remoto)" "./ClonarRepoGit.sh" \
FALSE "Eliminar un repositorio local" "./EliminarRepoGit.sh" \
FALSE "Agregar archivos al repositorio local (add)" "./AgregarArchivosGit.sh" \
FALSE "Subir archivos al repositorio remoto (commit+push)" "./AdicionarArchivosRepoRemotoGit.sh" \
FALSE "Crear una rama de un repositorio existente(branch)" "./RamificarRepositorio.sh" \
FALSE "Actualizar una rama de repositorio local respecto a una rama del repositorio remoto(pull)" "./ActualizarRepoLocal.sh" \
FALSE "Combinar una rama de un repositorio con la rama principal del mismo(merge)" "./CombinarRamas.sh" \
FALSE "Borrar una rama de un repositorio" "./BorrarRamaRepoGit.sh" \
FALSE "Cambiar la rama principal de un repositorio por otra de sus ramas(checkout)" "./CambiarRamaRepoGit.sh" \
FALSE "Visualizar los archivos de un repositorio" "./VisualizarRepo.sh" )


$comando