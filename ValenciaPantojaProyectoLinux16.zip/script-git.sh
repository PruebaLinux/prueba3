#!/bin/bash
ssalir=0
script=""
while [[ $ssalir = 0 ]];do
u=$(zenity --list --radiolist --column="" --column="Que hará" TRUE Instalar  FALSE Actualizar FALSE Crear_repositorio FALSE Ver_repositorios FALSE Trabajar_repositorio FALSE Copiar_repositorio FALSE Eliminar_repositorio FALSE Desinstalar FALSE Salir	)
b=apt-get
Debian=$(whereis "apt-get")
c=yum
Red=$(whereis "yum")
if [[ $u = "Instalar" ]]; then
	if [[ $Debian != $b: ]]; then
		zenity --question --text="¿Desea continuar?" --title="Instalará GIT" --cancel-label="Salir" --ok-label="Sí"
		salir=$?
		if [[ $salir = 0 ]]; then
  			while ! zenity --password| sudo -S cat /dev/null >/dev/null; do
    			if $(zenity --question --text="Contraseña incorrecta, ¿Quiere cancelar?" --ok-label="Sí" --cancel-label="No"); then
      			echo "Saliendo"
      			return;
      			fi
			done
			sudo apt-get install vlc 
			y=$?
			if [[ $y = 0  ]]; then
				zenity --info --text="GIT ha sido instalado"
			elif [[ $y = 1 ]]; then
				zenity --error --text="GIT NO ha sido instalado"
			fi
		else
			exit
		fi
	elif [[ $Red != $c: ]]; then
		zenity --question --text="¿Desea continuar?" --title="Instalará GIT" --cancel-label="Salir"
		salir=$?
		if [[ $salir = 0 ]]; then
  			while ! zenity --password| sudo -S cat /dev/null >/dev/null; do
    			if $(zenity --question --text="Contraseña incorrecta, ¿Quiere cancelar?" --ok-label="Sí" --cancel-label="No"); then
      			echo "Saliendo"
      			return;
      			fi
			done
			sudo yum install git
			y=$?
			if [[ $y = 0  ]]; then
				zenity --info --text="GIT ha sido instalado"
			elif [[ $y = 1 ]]; then
				zenity --error --text="GIT NO ha sido instalado"
			fi
		else
			exit
		fi
		echo "funcionó en Red Hat"
	else
		zenity --error --text="Éste no es un sistema Debian ni Red Hat"
	fi
##########################################################################################################################
elif [[ $u = "Desinstalar" ]]; then
	if [[ $Debian != $b: ]]; then
		zenity --question --text="¿Desea continuar?" --title="Desinstalará GIT" --cancel-label="Salir" --ok-label="Sí"
		salir=$?
		if [[ $salir = 0 ]]; then
			while ! zenity --password| sudo -S cat /dev/null >/dev/null; do
    			if $(zenity --question --text="Contraseña incorrecta, ¿Quiere cancelar?" --ok-label="Sí" --cancel-label="No"); then
      			echo "Saliendo"
      			return;
      			fi
			done			
			sudo apt-get --purge remove git 
			y=$?
			if [[ $y = 0  ]]; then
				zenity --info --text="GIT ha sido desinstalado"
			fi			
			echo "funcionó en Debian"
		else
			exit
		fi
	elif [[ $Red != $c: ]]; then
		zenity --question --text="¿Desea continuar?" --title="Desinstalará GIT" --cancel-label="Salir"
		salir=$?
		if [[ $salir = 0 ]]; then
  			while ! zenity --password| sudo -S cat /dev/null >/dev/null; do
    			if $(zenity --question --text="Contraseña incorrecta, ¿Quiere cancelar?" --ok-label="Sí" --cancel-label="No"); then
      			echo "Saliendo"
      			return;
      			fi
			done
			sudo yum remove git
			yum=$?
			if [[ $y = 0  ]]; then
				zenity --info --text="GIT ha sido desinstalado"
			fi			
			echo "funcionó en Debian"
		else
			exit
		fi
		echo "funcionó en Red Hat"
	else
		zenity --error --text="Éste no es un sistema Debian ni Red Hat"
	fi
###################################################################################################################
elif [[ $u = "Actualizar" ]]; then
	if [[ $Debian != $b: ]]; then
		zenity --question --text="¿Desea continuar?" --title="Actualizar GIT" --cancel-label="Salir" --ok-label="Sí"
		salir=$?
		if [[ $salir = 0 ]]; then
  			while ! zenity --password| sudo -S cat /dev/null >/dev/null; do
    			if $(zenity --question --text="Contraseña incorrecta, ¿Quiere cancelar?" --ok-label="Sí" --cancel-label="No"); then
      			echo "Saliendo"
      			return;
      			fi
			done
			sudo add-apt-repository ppa:git-core/ppa
			sudo apt-get update
			sudo apt-get install git 
			y=$?
			if [[ $y = 0  ]]; then
				zenity --info --text="GIT ha sido actualizado"
			elif [[ $y = 1 ]]; then
				zenity --error --text="GIT NO ha sido actualizado"
			fi
		else
			exit
		fi
	elif [[ $Red != $c: ]]; then
		zenity --question --text="¿Desea continuar?" --title="Desistalará GIT" --cancel-label="Salir"
		salir=$?
		if [[ $salir = 0 ]]; then
  			while ! zenity --password| sudo -S cat /dev/null >/dev/null; do
    			if $(zenity --question --text="Contraseña incorrecta, ¿Quiere cancelar?" --ok-label="Sí" --cancel-label="No"); then
      			echo "Saliendo"
      			return;
      			fi
			done
			sudo yum install git
			y=$?
			if [[ $y = 0  ]]; then
				zenity --info --text="GIT ha sido Actualizado"
			elif [[ $y = 1 ]]; then
				zenity --error --text="GIT NO ha sido Actualizado"
			fi
		else
			exit
		fi
		echo "funcionó en Red Hat"
	else
		zenity --error --text="Éste no es un sistema Debian ni Red Hat"
	fi
fi
################################################################################################################################################
if [[ $u = "Crear_repositorio" ]]; then
	cd ~
	if [[ -f .tem1p ]]; then
		echo "Sí existe .tem1p"
	else
		echo 0 > .tem1p
	fi
	if [ $(cat .tem1p) = 0 ]; then
		cat .tem1p
		carpeta=$(zenity --entry --title="Ingrese nombre" --text="Escriba nombre para la carpeta contendora") 
		mkdir $carpeta
		echo $carpeta > .temp_carpeta
		echo 1 > .tem1p
	fi
	if [[ -f .temp_carpeta ]]; then 
		cd $(cat .temp_carpeta)
		nombre=$(zenity --entry --title="Ingrese nombre repositorio" --text="Escriba nombre para el repositorio")
		nombre_usuario=$(zenity --entry --title="Ingrese nombre asociado al repositorio" --text="Escriba nombre de usuario") 
		correo=$(zenity --entry --title="Ingrese correo asociado al repositorio" --text="Escriba correo de usuario")
		mkdir $nombre
		cd $nombre
		git config --global user.name "$nombre_usuario"
		git config --global user.email $correo
		git init
	fi
	cd ~
fi
################################################################################################################################################
if [[ $u = "Ver_repositorios" ]]; then
	if [[ $(cat .temp_carpeta) != "" ]]; then
		cd ~
		cd $(cat .temp_carpeta)	
		ls | zenity --list --title "Ventana Emergente" --column "lista de repositorios"
		cd ~
	else
		zenity --error --text="No existen repositorios"
	fi
fi
################################################################################################################################################
if [[ $u = "Eliminar_repositorio" ]]; then
	if [[ $(cat .temp_carpeta) != "" ]]; then
		cd ~
		cd $(cat .temp_carpeta)
		rem=$(ls | zenity --list --title "lista de repositorios" --column "seleccione el repositorio a eliminar")
		zenity --question --title "¿esta seguro?" --ok-label="Si" --cancel-label="No" --text "¿Eliminar repositorio?"
		if [ $? = 0 ];then
			rm -r $rem
		fi
		cd ~
	else
		zenity --error --text="No existen repositorios"
	fi
fi
################################################################################################################################################
if [[ $u = "Copiar_repositorio" ]]; then
	if [[ $(cat .temp_carpeta) != "" ]]; then
		cd ~
		cd $(cat .temp_carpeta)
		copy=$(ls | zenity --list --title "lista de repositorios" --column "seleccione el repositorio a Copiar")
		nombrecp=$(zenity --entry --title="Ingrese nombre" --text="Escriba nombre para el repositorio seleccionado")
		zenity --question --title "¿Está seguro?" --ok-label="Sí" --cancel-label="No" --text "¿Desea copiar?"
		if [ $? = 0 ];then
			cp -r $copy $nombrecp
		fi
		cd ~
	else
		zenity --error --text="No existen repositorios"
	fi
fi
################################################################################################################################################
if [[ $u = "Trabajar_repositorio" ]]; then	
	cd ~
	if [[ $(cat .temp_carpeta) != "" ]]; then
		cd $(cat .temp_carpeta)	
		trab=$(ls | zenity --list --title "Ventana Emergente" --column "lista de repositorios")
		cd $trab
		if [[ $trab != "" ]];then
			salir1=0
			while [[ $salir1 = 0 ]];do
			if [[ $(git branch) = "" ]];then
				script=$(zenity --entry --title="Ingrese nombre" --text="Escriba nombre del script")
				$script > .tem_nombre
				touch $script
				if [[ $script != "" ]];then
					git add $script
					git commit
				fi
			fi
			t=$(zenity --list --radiolist --column="" --column="Qué hará" TRUE Ver_ramas  FALSE Crear_rama FALSE Trabajar_rama FALSE Eliminar_rama FALSE Cambiar_nombre_rama FALSE Volver)
			########################################################################################################################
			if [[ $t = "Ver_ramas" ]]; then
				git branch > .tempr		
				cat .tempr| zenity --list --title "Ventana Emergente" --column "lista de repositorios"
				rm -r .tempr		
			fi		
			########################################################################################################################
			if [[ $t = "Crear_rama" ]]; then
				rama=$(zenity --entry --title="Ingrese nombre" --text="Escriba nombre de la rama")
				if [[ $rama != "" ]];then
					git branch $rama
				fi			
			fi
			########################################################################################################################
			if [[ $t = "Eliminar_rama" ]]; then
				git branch > .tempr		
				elimr=$(cat .tempr| zenity --list --title "Ventana Emergente" --column "lista de repositorios")
				rm -r .tempr
				git branch -d $elimr		
			fi
			########################################################################################################################
			if [[ $t = "Cambiar_nombre_rama" ]]; then
				git branch > .tempr		
				raman=$(cat .tempr| zenity --list --title "Ventana Emergente" --column "lista de repositorios")
				rm -r .tempr
				git branch -m $raman $(zenity --entry --title="Cambiar nombre de la rama" --text="Escriba nuevo nombre de la rama")			
			fi
			########################################################################################################################
			if [[ $t = "Trabajar_rama" ]]; then
				git branch > .tempr		
				tra=$(cat .tempr| zenity --list --title "Ventana Emergente" --column "lista de repositorios")
				rm -r .tempr
				if [[ $tra != "" ]];then
					git checkout $tra
					nano $script
					salir2=0
					while [[ $salir2 = 0 ]];do
						l=$(zenity --list --radiolist --column="" --column="Qué hará" TRUE Subir_al_commit  FALSE subir_al_staged FALSE Trabajar_script FALSE Fusionar FALSE Volver)
						if [[ $l = "Subir_al_commit" ]]; then
							git add $script
							git commit
						fi
						if [[ $l = "subir_al_staged" ]]; then
							git add $script
						fi
						if [[ $l = "Trabajar_script" ]]; then
							nano $script
						fi
						if [[ $l = "Fusionar" ]]; then
							git branch > .tempr		
							git merge $(cat .tempr| zenity --list --title "lista de repositorios" --column "Escoja rama a fusionar")
							rm -r .tempr	
						fi
						if [[ $l = "Volver" ]]; then
							salir2=1
						elif [[ $l = "" ]]; then
							salir2=1
						fi
					done
				fi
			fi
			########################################################################################################################
			if [[ $t = "Volver" ]]; then
				salir1=1
			elif [[ $t = "" ]];then
				salir1=1
			fi
			done
		fi
	
		
	else
		zenity --error --text="No existen repositorios"
	fi
	cd ~
	
fi
################################################################################################################################################
if [[ $u = "Salir" ]]; then
	ssalir=1
elif [[ $u = "" ]];then
	ssalir=1
fi
################################################################################################################################################
done













